"""WTF? Confirming an answer on stackoverflow that made me smile :-)"""

print "confirmed"
